import React, { useState } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Nav from "react-bootstrap/Nav";
import { NavLink, Outlet, Link, useLocation } from "react-router-dom";
import { GiHamburgerMenu } from "react-icons/gi";
import { RiLogoutCircleRLine } from "react-icons/ri";
function Root() {
  const [toggle, setToggle] = useState(false);
  const url = useLocation();
  return (
    <div className="sidebar-sec">
      <div id="wrapper" className={toggle ? "" : "toggled"}>
        <div id="sidebar-wrapper">
          <div className="sidebar-nav">
            <div className="logo-wrap">
              <Link className="icon" to="/">
                Cloudforecast
              </Link>
              <GiHamburgerMenu
                className="sideClose-icon"
                onClick={() => setToggle(!toggle)}
              />
            </div>
            <div className="sidemenu-sec">
              <Nav
                defaultActiveKey="/home"
                className="flex-column nav-menu-wrap"
              >
                <Nav.Link
                  as={Link}
                  to="/step1"
                  active={url.pathname == "/step1"}
                >
                  WELCOME
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/step2"
                  active={url.pathname == "/step2"}
                >
                  CHOOSE YOUR OWN <br />
                  ADVENTURE
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/step3"
                  active={url.pathname == "/step3"}
                >
                  ENABLE COST AND <br />
                  USAGE REPORT
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/step4"
                  active={url.pathname == "/step4"}
                >
                  SETUP PERMISSION
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/step5"
                  active={url.pathname == "/step5"}
                >
                  CHOOSE YOUR PLAN
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/step6"
                  active={url.pathname == "/step6"}
                >
                  ENJOY!
                </Nav.Link>
              </Nav>
            </div>
            <div className="sidebar-brand">
              <Link to="/">
                <RiLogoutCircleRLine className="me-2" />
                lOG OUT
              </Link>
            </div>
          </div>
        </div>
        <div id="page-content-wrapper">
          <GiHamburgerMenu
            className="ham-icon"
            id="toggle-icon"
            onClick={() => setToggle(!toggle)}
          />
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Root;
