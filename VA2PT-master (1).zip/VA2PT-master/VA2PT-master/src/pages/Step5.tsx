import React from "react";
import { Button, Form } from "react-bootstrap";
function Step5() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          {/* choose plan */}
          <div className="setup-permission-content mb-5">
            <div className="sec-heading-title">
              <h2 className="sec-title mb-3">Choose Your Plan</h2>
              <p className="mb-4 meta-field-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                Perferendis dolore itaque deserunt quibusdam id asperiores, ad
                exercitationem voluptatibus a sit est earum nesciunt sequi
                minima, rerum ipsa nobis. Cum, nisi.
              </p>
            </div>
            <div className="radio-box-content">
              <Form>
                {["radio"].map((type) => (
                  <div key={`default-${type}`} className="mb-3">
                    <div>
                      <Form.Check
                        type={type}
                        id={`default-${type}-1`}
                        label="Community - Free"
                      />
                      <p className="ml-2">
                        Lorem ipsum dolor sit, amet consectetur adipisicing
                        elit.
                      </p>
                    </div>
                    <div>
                      <Form.Check
                        type={type}
                        id={`default-${type}-2`}
                        label="Community - Free"
                      />
                      <p className="ml-2">
                        Lorem ipsum dolor sit, amet consectetur adipisicing
                        elit.
                      </p>
                    </div>
                    <div>
                      <Form.Check
                        type={type}
                        id={`default-${type}-3`}
                        label="Community - Free"
                      />
                      <p className="ml-2">
                        Lorem ipsum dolor sit, amet consectetur adipisicing
                        elit.
                      </p>
                    </div>
                    <div>
                      <Form.Check
                        type={type}
                        id={`default-${type}-4`}
                        label="Community - Free"
                      />
                      <p className="ml-2">
                        Lorem ipsum dolor sit, amet consectetur adipisicing
                        elit.
                      </p>
                    </div>
                  </div>
                ))}
              </Form>
            </div>
            <div className="form-sec-wrap radio-btn">
              <Button className="btn-primary me-3" href="#">
                Next
              </Button>
            </div>
          </div>
          {/* choose plan closed */}
        </div>
      </div>
    </div>
  );
}

export default Step5;
