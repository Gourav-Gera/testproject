import React from "react";
import { Button, Form } from "react-bootstrap";

function Step2() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          {/* Choose ADVENTURE */}
          <div className="choose-advanture-content mb-5">
            <div className="sec-heading-title">
              <h2 className="sec-title">Choose your own advanture!</h2>
            </div>
            <p className="sec-content">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
              consequuntur veniam repellat nulla. Quisquam aut dolorum iste, vel
              recusandae, iure fugit tempore obcaecati hic quasi corporis esse
              itaque quis expedita!
            </p>
            <div className="form-sec-wrap">
              <Form className="form-sec-content">
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control type="text" placeholder="" />
                </Form.Group>
              </Form>
              <div className="btn-wrap flex-content-center">
                <Button className="btn-primary me-3" href="#">
                  Set Up Now
                </Button>
                <Button className="btn-overlay-primary" href="#">
                  Schedule A Phone Call
                </Button>
              </div>
            </div>
          </div>
          {/* choose advanture closed */}
        </div>
      </div>
    </div>
  );
}

export default Step2;
