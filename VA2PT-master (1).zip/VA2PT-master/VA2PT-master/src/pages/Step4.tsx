import React from "react";
import { Button, Form } from "react-bootstrap";

function Step4() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          {/* setup-permission-content */}
          <div className="setup-permission-content mb-5">
            <div className="sec-heading-title">
              <h2 className="sec-title mb-3">
                Setup Permission Using CloudPermission or Terraform
              </h2>
              <p className="mb-4 meta-field-text">
                <strong>1.</strong> Create CloudForecast AWS User Using either
                of the following options.
              </p>
              <ul className="attach-list">
                <li>
                  <Form.Group controlId="formFile" className="mb-3">
                    <Form.Label>Cloud Formation</Form.Label>
                    <Form.Control type="file" />
                  </Form.Group>
                </li>
                <li className="">
                  Terraform
                  <p className="text-field mb-0">
                    <strong className="primary-color me-2">
                      CloudForecast Module
                    </strong>
                    <span>with the following configuration:</span>
                  </p>
                  <ul className="list-wrap">
                    <li>
                      External Id: <strong>4549386549183498</strong>
                    </li>
                    <li>
                      S3 Bucket:{" "}
                      <strong>Sdjhdgafjknbhfbfhahdfbkllfhbk-v1</strong>
                    </li>
                  </ul>
                </li>
                <li className="">
                  Wait for the process to finish and copy the newly created ARN.
                  <p className="">
                    <span></span>
                  </p>
                </li>
              </ul>
            </div>
            <div className="form-sec-wrap">
              <Form className="form-sec-content">
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Enter the AWS IAM ARN</Form.Label>
                  <Form.Control type="text" placeholder="ARN" />
                </Form.Group>
              </Form>
              <Form className="checkbox-sec">
                {["checkbox"].map((type) => (
                  <div
                    key={`reverse-${type}`}
                    className="mb-3 text-left d-flex"
                  >
                    <Form.Check
                      reverse
                      label="Setup Cost and Usage Report"
                      name="group1"
                      type={type}
                      id={`reverse-${type}-1`}
                    />
                  </div>
                ))}
              </Form>
              <div className="help-btn-link">
                <span className="text-field">
                  Need help setting up your account? Our team is here to help.
                </span>
                <Button className="btn-primary me-3" href="#">
                  Schedule A Phone Call
                </Button>
              </div>
            </div>
          </div>
          {/* setup-permission-content closed */}
        </div>
      </div>
    </div>
  );
}

export default Step4;
