import React from "react";
import { Button, Form } from "react-bootstrap";
import { Link } from "react-router-dom";
function Step6() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          {/* congrats-field-content */}
          <div className="congrats-field-content mb-5">
            <div className="sec-heading-title">
              <h2 className="sec-title">Yay! Congrats you are done!</h2>
              <span className="mb-4 meta-field-text">
                Your first report will arive via email within 24 hours.
              </span>
            </div>
            <p className="mb-4 meta-field-text">
              Feel free to react out to us at <Link to="">Hello@VA@PT.com</Link>{" "}
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
              consequuntur.
            </p>
            <div className="btn-wrap">
              <Button className="btn-primary" href="#">
                Get Started
              </Button>
            </div>
          </div>
          {/* congrats-field-content closed */}
        </div>
      </div>
    </div>
  );
}

export default Step6;
