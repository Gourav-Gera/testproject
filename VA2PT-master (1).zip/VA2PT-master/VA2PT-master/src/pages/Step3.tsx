import React from "react";
import { Button, Form } from "react-bootstrap";
import { Link } from "react-router-dom";
function Step3() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          {/* enable-cost-content */}
          <div className="enable-cost-content mb-5">
            <div className="sec-heading-title">
              <h2 className="sec-title mb-3">Enable Cost and Usage Report</h2>
              <p className="mb-4 meta-field-text">
                Click <Link to="/">Here</Link> Lorem ipsum dolor sit amet
                consectetur adipisicing elit. Quis consequuntur.
              </p>
            </div>
            <div className="form-sec-wrap">
              <Form className="form-sec-content">
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Cost and usage prefix</Form.Label>
                  <Form.Control type="text" placeholder="" />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Label>Cost and usage prefix</Form.Label>
                  <Form.Control type="text" placeholder="" />
                </Form.Group>
              </Form>
              <Form className="checkbox-sec">
                {["checkbox"].map((type) => (
                  <div
                    key={`reverse-${type}`}
                    className="mb-3 text-left d-flex"
                  >
                    <Form.Check
                      reverse
                      label="Setup Cost and Usage Report"
                      name="group1"
                      type={type}
                      id={`reverse-${type}-1`}
                    />
                  </div>
                ))}
              </Form>
              <div className="btn-wrap flex-content-center flex-wrap">
                <Button className="btn-primary me-3" href="#">
                  Setup IAm Permission Using CloudFormation Or Terraform
                </Button>
                Or{" "}
                <Link to="/" className="setup-link">
                  Setup IAm Permission Using CloudFormation Or Terraform
                </Link>
              </div>
              <div className="help-btn-link">
                <span className="text-field">
                  Need help setting up your account? Our team is here to help.
                </span>
                <Button className="btn-primary me-3" href="#">
                  Schedule A Phone Call
                </Button>
              </div>
            </div>
          </div>
          {/* enable-cost-content closed */}
        </div>
      </div>
    </div>
  );
}

export default Step3;
