import React from "react";
import { Button, Form } from "react-bootstrap";

function Step1() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          <div className="welcome-field-content">
            <div className="sec-heading-title">
              <h2 className="sec-title">Welcome to Cloudforecast</h2>
              <span className="mb-4 meta-field-text">
                Thankyou for taking the time to check out us
              </span>
            </div>
            <p className="sec-content">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
              consequuntur veniam repellat nulla. Quisquam aut dolorum iste, vel
              recusandae, iure fugit tempore obcaecati hic quasi corporis esse
              itaque quis expedita!
            </p>
            <div className="form-sec-wrap">
              <Form className="form-sec-content">
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control type="email" placeholder="" />
                </Form.Group>
                <Button className="btn-primary" href="#">
                  Continue
                </Button>
              </Form>
            </div>
          </div>
          {/* Choose ADVENTURE */}
        </div>
      </div>
    </div>
  );
}

export default Step1;
